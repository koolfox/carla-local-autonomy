"use strict";

const state = {
  token: "",
  catalog: null,
  jobs: [],
  selectedJobId: null,
  selectedStream: "stdout",
  toastTimer: null,
};

const $ = (id) => document.getElementById(id);

function nowToken() {
  const date = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return [
    date.getUTCFullYear(),
    pad(date.getUTCMonth() + 1),
    pad(date.getUTCDate()),
    "t",
    pad(date.getUTCHours()),
    pad(date.getUTCMinutes()),
    pad(date.getUTCSeconds()),
    "z",
  ].join("");
}

function generatedId(prefix) {
  return `${prefix}-${nowToken()}`;
}

function number(id) {
  return Number($(id).value);
}

function checked(id) {
  return $(id).checked;
}

function showToast(message, isError = false) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("visible");
  window.clearTimeout(state.toastTimer);
  state.toastTimer = window.setTimeout(() => toast.classList.remove("visible"), 4200);
}

async function request(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.body !== undefined) {
    headers["Content-Type"] = "application/json";
  }
  if (options.method && options.method !== "GET") {
    headers["X-Operator-Token"] = state.token;
  }
  const response = await fetch(path, { ...options, headers });
  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload?.error?.message || `Request failed: ${response.status}`);
  }
  return payload;
}

function setOptions(id, values, placeholder = "No compatible item found", preferred = "") {
  const select = $(id);
  const previous = select.value;
  select.replaceChildren();
  if (!values.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = placeholder;
    select.append(option);
    return;
  }
  for (const value of values) {
    const option = document.createElement("option");
    option.value = typeof value === "string" ? value : value.value;
    option.textContent = typeof value === "string" ? value : value.label;
    select.append(option);
  }
  const candidates = [previous, preferred].filter(Boolean);
  for (const candidate of candidates) {
    if ([...select.options].some((option) => option.value === candidate)) {
      select.value = candidate;
      break;
    }
  }
}

function updateRange(inputId, outputId, digits = 0) {
  const render = () => {
    $(outputId).value = Number($(inputId).value).toFixed(digits);
  };
  $(inputId).addEventListener("input", render);
  render();
}

function selectPreferredWeight() {
  const detector = $("live-detector").value;
  const weights = state.catalog?.weights || [];
  const preferred =
    weights.find((value) => value.toLowerCase().includes(detector === "rtdetr" ? "rtdetr" : "yolo")) ||
    weights[0] ||
    "";
  setOptions("live-weights", weights, "Add a .pt weight file", preferred);
  $("live-confidence").value = detector === "rtdetr" ? "0.2" : "0.05";
  $("live-confidence").dispatchEvent(new Event("input"));
}

function populateCatalog(catalog, weatherPresets, propPresets) {
  state.catalog = catalog;
  const capabilities = catalog.capabilities;
  const carla = $("carla-status");
  carla.textContent = capabilities.carla_tcp_reachable
    ? "CARLA · reachable"
    : "CARLA · offline";
  carla.className = `status-pill ${capabilities.carla_tcp_reachable ? "ok" : "bad"}`;
  const pythonApi = $("pythonapi-status");
  pythonApi.textContent = capabilities.native_pythonapi_importable
    ? "PythonAPI · ready"
    : "PythonAPI · missing";
  pythonApi.className = `status-pill ${
    capabilities.native_pythonapi_importable ? "ok" : "bad"
  }`;

  const defaults = catalog.defaults;
  $("live-host").value = defaults.carla_host;
  $("live-port").value = defaults.carla_port;
  $("live-vehicle").value = defaults.vehicle_id;
  $("live-camera").value = defaults.camera_id;
  $("live-map").value = defaults.map;

  setOptions("situation-weather", weatherPresets);
  setOptions("situation-props", propPresets);
  setOptions("plan-suite", catalog.scenario_suites, "Save a situation first");
  setOptions(
    "plan-split",
    catalog.split_plans,
    "No split plan found",
    "configs/scenarios/split_plan_operator_development_v1.json",
  );
  setOptions("native-plan", catalog.scenario_plans, "Create a scenario plan first");
  setOptions("matrix-config", catalog.shadow_configs, "No matrix config found");
  setOptions("replay-config", catalog.replay_configs, "No replay config found");
  setOptions("replay-dataset", catalog.datasets, "No verified dataset found");
  setOptions("replay-evaluation", catalog.evaluation_configs, "No evaluation config found");
  setOptions("train-config", catalog.training_configs, "No training config found");
  setOptions("train-dataset", catalog.datasets, "No verified dataset found");
  setOptions("train-weights", catalog.weights, "No .pt weights found");
  setOptions("analysis-source", catalog.runtime_runs, "No recorded runtime found");
  setOptions(
    "verify-path",
    catalog.research_objects.map((row) => ({
      value: row.path,
      label: `${row.id} · ${row.status}`,
    })),
    "No research object found",
  );
  selectPreferredWeight();
}

function activateTab(name) {
  for (const tab of document.querySelectorAll(".tab")) {
    tab.classList.toggle("active", tab.dataset.tab === name);
  }
  for (const panel of document.querySelectorAll(".panel")) {
    panel.classList.toggle("active", panel.id === `panel-${name}`);
  }
}

async function startJob(kind, parameters) {
  const payload = {
    schema_version: "1.0",
    kind,
    parameters,
  };
  const job = await request("/api/jobs", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  state.selectedJobId = job.job_id;
  showToast(`${job.title} queued.`);
  await refreshJobs();
  activateTab("sessions");
}

function bindLiveForm() {
  $("live-run-id").value = generatedId("ui-live");
  $("live-detector").addEventListener("change", selectPreferredWeight);
  $("live-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = event.submitter;
    button.disabled = true;
    try {
      await startJob("live", {
        run_id: $("live-run-id").value,
        host: $("live-host").value,
        port: number("live-port"),
        vehicle_id: number("live-vehicle"),
        camera_id: number("live-camera"),
        resolution: $("live-resolution").value,
        camera_fps: number("live-camera-fps"),
        camera_fov: number("live-fov"),
        expected_map: $("live-map").value,
        detector: $("live-detector").value,
        weights: $("live-weights").value,
        model_package: "",
        device: $("live-device").value,
        image_size: number("live-image-size"),
        confidence: number("live-confidence"),
        control: $("live-control").value,
        cruise_speed: number("live-cruise-speed"),
        duration: number("live-duration"),
        max_stale_seconds: number("live-stale"),
        view: $("live-view").value,
        record_video: checked("live-video"),
        shadow_policy: $("live-policy").value,
        policy_options: {
          confidence: 0.35,
          close_bottom: number("live-close-bottom"),
          corridor_left: 0.3,
          corridor_right: 0.7,
          cruise_throttle: 0.15,
        },
        acknowledge_teacher_motion: checked("live-motion-ack"),
      });
      $("live-run-id").value = generatedId("ui-live");
    } catch (error) {
      showToast(error.message, true);
    } finally {
      button.disabled = false;
    }
  });
}

function situationPayload() {
  return {
    situation_id: $("situation-id").value,
    map_name: $("situation-map").value,
    weather_preset: $("situation-weather").value,
    vehicle_count: number("vehicle-count"),
    walker_count: number("walker-count"),
    pedestrian_crossing_factor: number("crossing"),
    speed_difference_percent: number("speed-difference"),
    following_distance_metres: number("following-distance"),
    prop_preset: $("situation-props").value,
    ego_blueprint: $("situation-ego").value,
    ego_spawn_index: number("situation-spawn"),
    duration_seconds: number("situation-duration"),
    capture_fps: number("situation-capture-fps"),
    repetitions: number("situation-repetitions"),
    master_seed: number("situation-seed"),
    camera_width: number("situation-width"),
    camera_height: number("situation-height"),
    camera_fov: number("situation-fov"),
  };
}

async function refreshBootstrap() {
  const bootstrap = await request("/api/bootstrap");
  state.token = bootstrap.token;
  populateCatalog(
    bootstrap.catalog,
    bootstrap.weather_presets,
    bootstrap.prop_presets,
  );
  state.jobs = bootstrap.jobs;
  renderJobs();
}

function bindSituationForms() {
  $("plan-run-id").value = generatedId("ui-plan");
  $("situation-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = event.submitter;
    button.disabled = true;
    const result = $("situation-result");
    try {
      const payload = await request("/api/situations", {
        method: "POST",
        body: JSON.stringify(situationPayload()),
      });
      result.textContent = `Saved ${payload.path}`;
      result.className = "inline-result ok";
      showToast("Situation recipe saved and validated.");
      await refreshBootstrap();
      $("plan-suite").value = payload.path;
      $("plan-run-id").value = `plan-${$("situation-id").value}-${nowToken()}`;
    } catch (error) {
      result.textContent = error.message;
      result.className = "inline-result";
      showToast(error.message, true);
    } finally {
      button.disabled = false;
    }
  });
  $("plan-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await startJob("scenario_plan", {
        suite: $("plan-suite").value,
        split_plan: $("plan-split").value,
        run_id: $("plan-run-id").value,
      });
      $("plan-run-id").value = generatedId("ui-plan");
    } catch (error) {
      showToast(error.message, true);
    }
  });
}

function bindWorkflowForms() {
  $("native-dataset-id").value = generatedId("ds-ui");
  $("matrix-id").value = generatedId("shadow-ui");
  $("replay-id").value = generatedId("replay-ui");
  $("train-run-id").value = generatedId("train-ui");
  $("analysis-run-id").value = generatedId("analysis-ui");

  $("native-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await startJob("native_capture", {
        scenario_plan: $("native-plan").value,
        dataset_id: $("native-dataset-id").value,
        host: state.catalog.defaults.carla_host,
        port: state.catalog.defaults.carla_port,
        partition: $("native-partition").value,
        max_episodes: number("native-max-episodes"),
        timeout: 30,
        sensor_timeout: 10,
        carla_python_api: $("native-pythonapi").value,
        dry_run: checked("native-dry-run"),
        acknowledge_exclusive_tick_owner: checked("native-ack"),
      });
      $("native-dataset-id").value = generatedId("ds-ui");
    } catch (error) {
      showToast(error.message, true);
    }
  });

  $("native-preflight").addEventListener("click", async () => {
    try {
      const confirmed = checked("native-ack");
      await startJob("native_preflight", {
        scenario_plan: $("native-plan").value,
        dataset_id: $("native-dataset-id").value,
        run_id: generatedId("native-preflight-ui"),
        host: state.catalog.defaults.carla_host,
        port: state.catalog.defaults.carla_port,
        partition: $("native-partition").value,
        max_episodes: number("native-max-episodes"),
        timeout: 3,
        carla_python_api: $("native-pythonapi").value,
        confirm_world_reload: confirmed,
        confirm_exclusive_tick_owner: confirmed,
      });
    } catch (error) {
      showToast(error.message, true);
    }
  });

  $("matrix-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await startJob("shadow_matrix", {
        config: $("matrix-config").value,
        matrix_id: $("matrix-id").value,
        execute: checked("matrix-execute"),
        acknowledge_teacher_motion: checked("matrix-ack"),
      });
      $("matrix-id").value = generatedId("shadow-ui");
    } catch (error) {
      showToast(error.message, true);
    }
  });

  $("replay-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await startJob("replay", {
        config: $("replay-config").value,
        replay_id: $("replay-id").value,
        dataset: $("replay-dataset").value,
        evaluation_config: $("replay-evaluation").value,
        acknowledge_locked_test: checked("replay-locked"),
      });
      $("replay-id").value = generatedId("replay-ui");
    } catch (error) {
      showToast(error.message, true);
    }
  });

  $("train-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await startJob("train", {
        config: $("train-config").value,
        dataset: $("train-dataset").value,
        weights: $("train-weights").value,
        run_id: $("train-run-id").value,
        device: $("train-device").value,
        dry_run: checked("train-dry-run"),
        acknowledge_real_training: checked("train-ack"),
      });
      $("train-run-id").value = generatedId("train-ui");
    } catch (error) {
      showToast(error.message, true);
    }
  });

  $("analysis-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await startJob("analyze", {
        source_run: $("analysis-source").value,
        run_id: $("analysis-run-id").value,
      });
      $("analysis-run-id").value = generatedId("analysis-ui");
    } catch (error) {
      showToast(error.message, true);
    }
  });

  $("verify-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await startJob("verify", {
        paths: [$("verify-path").value],
        allow_non_success: checked("verify-non-success"),
      });
    } catch (error) {
      showToast(error.message, true);
    }
  });
}

function statusClass(status) {
  if (status === "success") return "ok";
  if (["failed", "stopped"].includes(status)) return "bad";
  if (["queued", "starting", "running", "stopping", "finalizing"].includes(status)) {
    return "running";
  }
  return "neutral";
}

function isActive(status) {
  return ["queued", "starting", "running", "stopping", "finalizing"].includes(status);
}

function readableTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? value : date.toLocaleTimeString();
}

function renderJobs() {
  const body = $("jobs-body");
  body.replaceChildren();
  if (!state.jobs.length) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 4;
    cell.className = "empty-state";
    cell.textContent = "No operator sessions yet.";
    row.append(cell);
    body.append(row);
  }
  for (const job of state.jobs) {
    const row = document.createElement("tr");
    row.className = `session-row ${state.selectedJobId === job.job_id ? "selected" : ""}`;
    row.addEventListener("click", () => selectJob(job.job_id));

    const statusCell = document.createElement("td");
    const status = document.createElement("span");
    status.className = `status-pill ${statusClass(job.status)}`;
    status.textContent = job.status;
    statusCell.append(status);

    const titleCell = document.createElement("td");
    const title = document.createElement("span");
    title.className = "session-title";
    title.textContent = job.title;
    const id = document.createElement("span");
    id.className = "session-id";
    id.textContent = job.job_id;
    titleCell.append(title, id);

    const timeCell = document.createElement("td");
    timeCell.textContent = readableTime(job.started_at || job.created_at);

    const actionCell = document.createElement("td");
    if (isActive(job.status)) {
      const stop = document.createElement("button");
      stop.type = "button";
      stop.className = "row-action stop";
      stop.textContent = "Stop";
      stop.addEventListener("click", async (event) => {
        event.stopPropagation();
        try {
          await request(`/api/jobs/${encodeURIComponent(job.job_id)}/stop`, {
            method: "POST",
            body: "{}",
          });
          showToast("Stop requested.");
          await refreshJobs();
        } catch (error) {
          showToast(error.message, true);
        }
      });
      actionCell.append(stop);
    } else {
      const inspect = document.createElement("button");
      inspect.type = "button";
      inspect.className = "row-action";
      inspect.textContent = "Inspect";
      actionCell.append(inspect);
    }
    row.append(statusCell, titleCell, timeCell, actionCell);
    body.append(row);
  }
  const activeCount = state.jobs.filter((job) => isActive(job.status)).length;
  $("jobs-status").textContent = `${activeCount} active job${activeCount === 1 ? "" : "s"}`;
  $("jobs-status").className = `status-pill ${activeCount ? "running" : "neutral"}`;
  $("session-count").textContent = state.jobs.length;
  if (state.selectedJobId) {
    renderInspector();
  }
}

async function selectJob(jobId) {
  state.selectedJobId = jobId;
  renderJobs();
  await renderInspector();
}

function artifactLink(container, label, path) {
  const link = document.createElement("a");
  link.href = `/api/artifact?path=${encodeURIComponent(path)}`;
  link.target = "_blank";
  link.rel = "noreferrer";
  link.textContent = label;
  container.append(link);
}

async function renderInspector() {
  const job = state.jobs.find((candidate) => candidate.job_id === state.selectedJobId);
  if (!job) return;
  $("selected-job-title").textContent = job.title;
  $("selected-job-status").textContent = job.status;
  $("selected-job-status").className = `status-pill ${statusClass(job.status)}`;
  $("selected-job-note").textContent = job.error || job.note || "Operator session";
  const links = $("artifact-links");
  links.replaceChildren();
  const sessionRelative = `operator_sessions/${job.job_id}`;
  artifactLink(links, "session manifest", `${sessionRelative}/manifest.json`);
  artifactLink(links, "request", `${sessionRelative}/request.json`);
  artifactLink(links, "command", `${sessionRelative}/command.json`);
  artifactLink(links, "status", `${sessionRelative}/status.json`);
  if (job.expected_output_exists && job.expected_output) {
    const workspace = state.catalog.workspace.replace(/\/+$/, "");
    const relative = job.expected_output.startsWith(workspace)
      ? job.expected_output.slice(workspace.length + 1)
      : job.expected_output;
    artifactLink(links, "child manifest", `${relative}/manifest.json`);
    const image = $("session-preview");
    image.src = `/api/artifact?path=${encodeURIComponent(
      `${relative}/images/latest_overlay.png`,
    )}&t=${Date.now()}`;
    image.onload = () => {
      image.style.display = "block";
    };
    image.onerror = () => {
      image.style.display = "none";
    };
    const videoPath = `${relative}/video/overlay.mp4`;
    artifactLink(links, "overlay video", videoPath);
  } else {
    $("session-preview").style.display = "none";
  }
  try {
    const payload = await request(
      `/api/jobs/${encodeURIComponent(job.job_id)}/log?stream=${state.selectedStream}`,
    );
    $("job-log").textContent = payload.text || "(log is empty)";
    $("job-log").scrollTop = $("job-log").scrollHeight;
  } catch (error) {
    $("job-log").textContent = error.message;
  }
}

async function refreshJobs() {
  try {
    const payload = await request("/api/jobs");
    state.jobs = payload.jobs;
    renderJobs();
  } catch (error) {
    showToast(error.message, true);
  }
}

function bindChrome() {
  for (const tab of document.querySelectorAll(".tab")) {
    tab.addEventListener("click", () => activateTab(tab.dataset.tab));
  }
  for (const tab of document.querySelectorAll(".log-tab")) {
    tab.addEventListener("click", async () => {
      state.selectedStream = tab.dataset.stream;
      for (const candidate of document.querySelectorAll(".log-tab")) {
        candidate.classList.toggle("active", candidate === tab);
      }
      await renderInspector();
    });
  }
  $("refresh-jobs").addEventListener("click", refreshJobs);
  updateRange("live-confidence", "live-confidence-value", 2);
  updateRange("vehicle-count", "vehicle-count-value");
  updateRange("walker-count", "walker-count-value");
  updateRange("crossing", "crossing-value", 2);
}

async function initialize() {
  bindChrome();
  bindLiveForm();
  bindSituationForms();
  bindWorkflowForms();
  try {
    await refreshBootstrap();
  } catch (error) {
    showToast(`Could not initialize operator panel: ${error.message}`, true);
  }
  window.setInterval(refreshJobs, 1800);
}

window.addEventListener("DOMContentLoaded", initialize);
