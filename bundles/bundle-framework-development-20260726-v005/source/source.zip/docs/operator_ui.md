# CARLA Vision Operator UI

Status: local proof-of-concept operator console  
Binding policy: loopback only  
Control policy: vision proposals never actuate the vehicle

## Purpose

The operator UI gives a thesis researcher one simple place to:

- start a live detector and annotated recording;
- select RT-DETR or YOLO weights and runtime settings;
- enable a non-actuating vision-policy shadow;
- compose traffic, pedestrians, crossing probability, weather, props, camera,
  duration, and seed without editing scenario JSON;
- resolve a situation into deterministic episode plans;
- dry-run or explicitly authorize native dataset collection;
- plan or execute a live detector/policy matrix;
- replay models over an identical dataset order;
- dry-run or explicitly authorize training;
- create post-hoc metrics and plots;
- verify retained datasets, runs, models, reports, and bundles;
- inspect job status, logs, manifests, overlays, and videos.

It is intentionally a small orchestration layer over the existing strict
Python CLIs. It does not duplicate simulator, dataset, training, replay, or
verification logic.

## Start

```bash
uv run carla-operator-ui --open-browser
```

The default address is:

```text
http://127.0.0.1:8765/
```

The server refuses non-loopback bind addresses. It launches local processes
and can authorize simulator mutation, so it must not be exposed as an
unauthenticated network service.

## Four operator surfaces

### Live & Record

The form selects:

- CARLA host/port and existing vehicle/camera actor IDs;
- expected map, resolution, camera FPS, and FOV;
- RT-DETR or YOLO weight file, device, image size, and confidence floor;
- no motion or privileged low-speed teacher motion;
- no policy or the built-in hazard-stop shadow;
- split/overlay/headless view, duration, stale limit, and MP4 retention.

Teacher motion requires a per-launch acknowledgement. The runtime opens its
existing exact-frame OpenCV viewer. Policy proposals are shown in the HUD and
written to `policy_shadow.jsonl`; they are never applied.

### Situation Builder

The situation form maps a small operator-facing schema onto the full existing
`ScenarioSuite` contract. It exposes the controls most useful for a thesis
MVP:

- map and ego spawn index;
- named coherent weather preset;
- number of traffic vehicles and pedestrians;
- pedestrian crossing probability;
- Traffic Manager speed difference and following distance;
- none, cones, construction, or accident static-prop preset;
- camera resolution/FOV and capture FPS;
- episode duration, repetitions, and master seed.

Saving produces:

```text
operator_configs/situations/<situation-id>.json
```

The output is validated by the same strict scenario classes used by the native
worker. It can then be resolved through the operator development split plan
into a normal checksum-tracked scenario-plan run.

Saving and planning are offline. They do not connect to CARLA.

### Research Workflows

The UI exposes six existing workflows:

1. **Native preflight and capture** — the preflight verifies the plan,
   endpoint, versions, PythonAPI, output ID, and manual gates through
   read-only operations and creates a standalone readiness artifact. Capture
   remains dry-run by default. Real execution requires the official matching
   PythonAPI plus acknowledgement of map reload, actor destruction, and
   exclusive `world.tick()` ownership.
2. **Live shadow matrix** — derives a new immutable matrix ID from a selected
   template. Plan mode is offline; teacher-driven execution requires
   acknowledgement.
3. **Paired replay** — derives a new replay ID while retaining the selected
   frozen template values and resolved model paths.
4. **Training** — dry-run by default. Real training requires a separate
   compute acknowledgement.
5. **Analysis** — creates source-linked frame CSV, metrics, and plots from a
   recorded runtime.
6. **Verification** — performs recursive read-only hash and semantic checks.

The backend accepts no shell string. Every workflow has an explicit parameter
allow-list and is launched as a token array through the current Python
environment. Workspace inputs cannot escape the project path. Existing output
IDs are never overwritten.

### Sessions

Each launch creates:

```text
operator_sessions/<operator-job-id>/
├── manifest.json
├── request.json
├── command.json
├── status.json
└── logs/
    ├── stdout.log
    └── stderr.log
```

The session uses `RunArtifactTracker`, so all five payloads receive SHA-256,
byte-size, role, environment, hardware, Git, and configuration provenance.
When a child run/dataset exists, its manifest fingerprint is added as an input
reference.

Verify an operator session with:

```bash
uv run carla-verify \
  operator_sessions/<operator-job-id> \
  --reject-unregistered
```

A stopped or failed session remains evidence and can be inspected with
`--allow-non-success`.

## Safety model

- The UI binds only to `127.0.0.1`, `::1`, or `localhost`.
- State-changing requests require a per-server same-origin token.
- Arbitrary commands and shell evaluation are not supported.
- Workspace file selections are path-contained and must already exist.
- Output directories must not exist.
- `vision` control is absent from the UI and still rejected by the runtime.
- Teacher motion, native mutation, locked-test access, and real training have
  separate visible acknowledgements.
- Native dry-run does not import CARLA or contact the simulator.
- Closing the UI asks active child processes to terminate; runtime watchdog
  and final-stop behavior remain authoritative.

The token is a local cross-origin request guard, not user authentication. This
POC is deliberately not a remotely hosted multi-user service.

## Current limitations

- The UI launches the existing native OpenCV viewer rather than re-encoding a
  low-latency browser video stream.
- It offers named weather/prop presets instead of exposing every CARLA
  attribute.
- It creates one situation recipe at a time; multi-recipe thesis suites remain
  JSON-configured.
- It does not edit training hyperparameters, ontologies, or model-package
  contracts in the browser.
- Replay and matrix runs derive new IDs from templates but do not create an
  experiment registry.
- Restarting the UI preserves completed session files, but it does not resume
  interrupted subprocesses.
- There is no authentication, remote access, scheduling queue, database, or
  role system by design.

These constraints keep the interface at the requested thesis POC/MVP scale.

## Validated development smoke

The UI backend was exercised through its real HTTP API to save
`town10-ui-poc-v1` and launch `scenario-plan-operator-poc-v1`. The retained
operator session completed with code zero, no motion or destructive
authorization, and a verified child manifest containing one episode and 75
planned captures.

The first verification smoke exposed an internal module-entry-point defect.
That session was retained, the allow-listed invocation was corrected, and a
new real verification session produced the expected recursive output. See
[Validation report v0.6](validation_report_v0.6.md) for IDs, hashes, test
counts, and the claim boundary.

The native-preflight button was also exercised through the real HTTP API. It
launched a non-destructive operator job, created
`native-preflight-ui-20260726-v1`, fingerprinted the child manifest, and
correctly reported that the CARLA 0.9.16 endpoint is reachable while the local
Apple arm64 host lacks the official PythonAPI required for collection.
