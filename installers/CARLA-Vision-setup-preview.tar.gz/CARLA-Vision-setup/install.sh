#!/bin/sh
set -eu
InstallerDirectory=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec sh "$InstallerDirectory/app/deploy/desktop/install.sh" "$@"
