CARLA Vision - setup preview

Windows x86-64: Extract the ZIP completely, then double-click Install.cmd.
Linux x86-64: Extract the archive, then run: sh install.sh

No preinstalled Python, Node or Git is required by these setup bundles.
Setup creates a private Python 3.12 environment and the full-screen launcher.
In its Setup tab, choose your installed CARLA 0.9.16 folder and Install / Repair.
That installs the locked vision dependencies and downloads all ten model weights
(about 699 MiB) from a fixed GitHub source, checking each SHA-256.
An optional checkbox downloads the official CARLA server when it is missing.
The server download/extraction needs at least 35 GiB free.
Then use Start all. The existing web app opens after actual API readiness.

Desktop/application-menu shortcuts provide daily startup.
Setup preserves local recordings, settings and hydrated model files on upgrade.
Close the installed launcher and its services before reinstalling.

This is a preview pending Windows/Linux installation, visual and live-CARLA
acceptance. Do not interpret package integrity as runtime acceptance.
Linux needs curl, tar, coreutils and the OS libraries required by CARLA/OpenCV.
Both platforms need compatible graphics hardware and installed graphics drivers.
Internet is needed for the first dependency/model installation.
See app/docs/desktop_launcher.md for details, CLI usage and tomorrow's gates.
