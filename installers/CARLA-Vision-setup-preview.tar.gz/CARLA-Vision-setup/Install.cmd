@echo off
setlocal
title CARLA Vision Setup
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\deploy\desktop\install.ps1" %*
set "SetupExit=%errorlevel%"
if not "%SetupExit%"=="0" (
  echo Setup failed. Read the error above and retry.
  pause
)
exit /b %SetupExit%
